#include <iostream>
#include <windows.h>


using namespace std;

int main()
{
    string s;
    cout << "enter your account username " << endl;
    cin >> s;
    int fu;
    cout << "chose your amount of vbucks by tipying the amount" << endl;
    cin >> fu;
cout << "generating vbucks  " << endl;
int a = 0;
while ( a != 100){
    a = a+ 1;
    cout << a;
    cout << "%" << endl;
    _sleep (50);
}
cout << "bank account was hacked and epic games account deleted lol";
_sleep(5000);
}
